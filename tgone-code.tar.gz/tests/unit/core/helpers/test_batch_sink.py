import pytest
import asyncio
from types import SimpleNamespace
from unittest.mock import patch, AsyncMock

from core.helpers.batch_sink import TaskStatusSink


@pytest.fixture
def mock_db_manager():
    with patch("core.db_factory.AsyncSessionManager") as mock_manager:
        yield mock_manager


@pytest.fixture
async def sink_instance():
    # 因为是单例模式，清空一下之前可能残留的状态
    sink = TaskStatusSink()
    # 强制清理队列并停止运行态
    sink._queue = asyncio.Queue()
    sink._flush_event = asyncio.Event()
    sink._processing_tasks = set()
    sink._flush_lock = asyncio.Lock()
    sink._process_lock = asyncio.Lock()
    sink._running = False
    if sink._daemon_task and not sink._daemon_task.done():
        sink._daemon_task.cancel()

    yield sink

    # 清理收尾，防止守护协程阻碍事件循环退出
    await sink.stop()


@pytest.mark.asyncio
async def test_singleton():
    sink1 = TaskStatusSink()
    sink2 = TaskStatusSink()
    assert sink1 is sink2, "TaskStatusSink 必须是单例模式"


@pytest.mark.asyncio
async def test_put_item(sink_instance):
    assert sink_instance._queue.empty()
    await sink_instance.put(task_id=1, action='complete')
    await sink_instance.put(task_id=2, action='fail', error_message='TIMEOUT')

    assert sink_instance._queue.qsize() == 2
    item1 = sink_instance._queue.get_nowait()
    item2 = sink_instance._queue.get_nowait()

    assert item1 == {'id': 1, 'action': 'complete', 'error_message': None}
    assert item2 == {'id': 2, 'action': 'fail', 'error_message': 'TIMEOUT'}


@pytest.mark.asyncio
async def test_flush_process_batch_segregation(sink_instance, mock_db_manager):
    # 构建 Mock 的 AsyncSessionManager
    mock_session = AsyncMock()
    mock_session.execute.return_value.rowcount = 1

    # 巧妙构造 AsyncContextManager
    mock_db_manager.return_value.__aenter__.return_value = mock_session
    mock_db_manager.return_value.__aexit__.return_value = None

    # 塞入混合的事件
    await sink_instance.put(101, 'complete')
    await sink_instance.put(102, 'fail', 'err')
    await sink_instance.put(103, 'complete')

    assert sink_instance._queue.qsize() == 3

    # 手动触发 flush 清空池子
    await sink_instance.flush()
    # 等待后台的 process_batch 协程执行完
    await asyncio.sleep(0.1)

    assert sink_instance._queue.empty()
    assert mock_session.commit.called, "必须触发 session.commit()"
    assert mock_session.execute.call_count == 2, (
        "应该触发2次执行，一次处理 complete 批次，一次处理失败"
    )


@pytest.mark.asyncio
async def test_flush_serializes_db_writes(sink_instance, monkeypatch):
    active_writes = 0
    max_active_writes = 0
    first_write_started = asyncio.Event()

    class FakeSession:
        async def execute(self, *args, **kwargs):
            nonlocal active_writes, max_active_writes
            active_writes += 1
            max_active_writes = max(max_active_writes, active_writes)
            first_write_started.set()
            await asyncio.sleep(0.05)
            active_writes -= 1
            return SimpleNamespace(rowcount=1)

        async def commit(self):
            return None

    class FakeSessionManager:
        async def __aenter__(self):
            return FakeSession()

        async def __aexit__(self, exc_type, exc, tb):
            return None

    monkeypatch.setattr(
        "core.db_factory.AsyncSessionManager",
        FakeSessionManager,
    )

    await sink_instance.put(301, "complete")
    first_flush = asyncio.create_task(sink_instance.flush(wait=True))
    await first_write_started.wait()

    await sink_instance.put(302, "complete")
    second_flush = asyncio.create_task(sink_instance.flush(wait=True))

    await asyncio.gather(first_flush, second_flush)

    assert max_active_writes == 1


@pytest.mark.asyncio
async def test_start_stop_lifecycle(sink_instance):
    # 降低心跳间隔加速测试
    sink_instance._flush_interval = 0.05

    assert not sink_instance._running
    sink_instance.start()
    assert sink_instance._running
    assert sink_instance._daemon_task is not None
    assert not sink_instance._daemon_task.done()

    # 发送几条消息
    await sink_instance.put(201, 'complete')
    await sink_instance.put(202, 'complete')

    # 等待 daemon_loop 自动执行一次心跳
    await asyncio.sleep(0.15)

    # 断言消息已被自动消费
    assert sink_instance._queue.empty()

    # 停止它
    await sink_instance.stop()
    assert not sink_instance._running
    assert (
        sink_instance._daemon_task.done()
        or sink_instance._daemon_task.cancelled()
    )


@pytest.mark.asyncio
async def test_stop_logs_cancelled_daemon_task(sink_instance, caplog):
    async def pending_daemon():
        await asyncio.Event().wait()

    sink_instance._running = True
    sink_instance._daemon_task = asyncio.create_task(pending_daemon())
    await asyncio.sleep(0)
    caplog.set_level("DEBUG", logger="core.helpers.batch_sink")

    await sink_instance.stop()

    assert "TaskStatusSink 守护任务已取消" in caplog.text


@pytest.mark.asyncio
async def test_daemon_does_not_flush_when_idle(sink_instance, monkeypatch):
    sink_instance._flush_interval = 0.01
    flush_calls = 0

    async def fake_flush(wait: bool = False):
        nonlocal flush_calls
        flush_calls += 1

    monkeypatch.setattr(sink_instance, "flush", fake_flush)

    sink_instance.start()
    await asyncio.sleep(0.04)

    assert flush_calls == 0
