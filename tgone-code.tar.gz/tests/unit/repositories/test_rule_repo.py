import logging

import pytest
from repositories.rule_repo import RuleRepository
from models.models import ForwardRule, Chat
from core.container import container

@pytest.mark.asyncio
@pytest.mark.usefixtures("clear_data")
class TestRuleRepository:
    @pytest.fixture
    def repo(self):
        return RuleRepository(container.db)

    async def test_find_chat(self, repo, db):
        # 创建一个聊天
        chat = Chat(telegram_chat_id="-100123456789", name="Test Chat")
        db.add(chat)
        await db.commit()

        # 精确查找
        found = await repo.find_chat("-100123456789")
        assert found is not None
        assert found.name == "Test Chat"

        # 变体查找 (比如省略 -100)
        found_variant = await repo.find_chat("123456789")
        assert found_variant is not None
        assert found_variant.id == chat.id

    async def test_get_rules_for_source_chat(self, repo, db):
        # 创建聊天和规则
        chat = Chat(telegram_chat_id="-1001", name="Src")
        db.add(chat)
        await db.commit()
        
        target = Chat(telegram_chat_id="-1002", name="Dst")
        db.add(target)
        await db.commit()

        rule = ForwardRule(source_chat_id=chat.id, target_chat_id=target.id)
        db.add(rule)
        await db.commit()

        # 测试获取规则
        rules = await repo.get_rules_for_source_chat("-1001")
        assert len(rules) == 1
        assert rules[0].id == rule.id

        # 测试缓存 (修改数据库但不清除缓存)
        rule.enable_rule = False
        await db.commit()
        
        rules_cached = await repo.get_rules_for_source_chat("-1001")
        assert len(rules_cached) == 1 # 应该还是原来的规则列表（缓存中）

        # 清除缓存
        repo.clear_cache()
        rules_fresh = await repo.get_rules_for_source_chat("-1001")
        assert len(rules_fresh) == 0

    async def test_get_priority_map_logs_cache_read_failure(
        self,
        repo,
        db,
        monkeypatch,
        caplog,
    ):
        source = Chat(telegram_chat_id="-1001", name="Src")
        target = Chat(telegram_chat_id="-1002", name="Dst")
        db.add_all([source, target])
        await db.commit()

        rule = ForwardRule(
            source_chat_id=source.id,
            target_chat_id=target.id,
            priority=42,
            enable_rule=True,
        )
        db.add(rule)
        await db.commit()

        class FailingReadCache:
            def get(self, key):
                raise RuntimeError("priority cache read unavailable")

            def set(self, key, value, ttl=None):
                return None

        monkeypatch.setattr(
            "repositories.rule_repo.get_persistent_cache",
            lambda: FailingReadCache(),
        )
        caplog.set_level(logging.WARNING, logger="repositories.rule_repo")

        priority_map = await repo.get_priority_map()

        assert priority_map[-1001] == 42
        assert "Rule priority map cache read failed" in caplog.text
        assert "priority cache read unavailable" in caplog.text

    async def test_get_priority_map_logs_cache_write_failure(
        self,
        repo,
        db,
        monkeypatch,
        caplog,
    ):
        source = Chat(telegram_chat_id="-1003", name="Src")
        target = Chat(telegram_chat_id="-1004", name="Dst")
        db.add_all([source, target])
        await db.commit()

        rule = ForwardRule(
            source_chat_id=source.id,
            target_chat_id=target.id,
            priority=7,
            enable_rule=True,
        )
        db.add(rule)
        await db.commit()

        class FailingWriteCache:
            def get(self, key):
                return None

            def set(self, key, value, ttl=None):
                raise RuntimeError("priority cache write unavailable")

        monkeypatch.setattr(
            "repositories.rule_repo.get_persistent_cache",
            lambda: FailingWriteCache(),
        )
        caplog.set_level(logging.WARNING, logger="repositories.rule_repo")

        priority_map = await repo.get_priority_map()

        assert priority_map[-1003] == 7
        assert "Rule priority map cache write failed" in caplog.text
        assert "priority cache write unavailable" in caplog.text

    async def test_get_priority_map_logs_invalid_candidate_and_keeps_valid(
        self,
        repo,
        db,
        monkeypatch,
        caplog,
    ):
        source = Chat(telegram_chat_id="-1005", name="Src")
        target = Chat(telegram_chat_id="-1006", name="Dst")
        db.add_all([source, target])
        await db.commit()

        rule = ForwardRule(
            source_chat_id=source.id,
            target_chat_id=target.id,
            priority=13,
            enable_rule=True,
        )
        db.add(rule)
        await db.commit()

        class EmptyCache:
            def get(self, key):
                return None

            def set(self, key, value, ttl=None):
                return None

        monkeypatch.setattr(
            "repositories.rule_repo.get_persistent_cache",
            lambda: EmptyCache(),
        )
        monkeypatch.setattr(
            "repositories.rule_repo.build_candidate_telegram_ids",
            lambda chat_id: ["bad-candidate", str(chat_id)],
        )
        caplog.set_level(logging.WARNING, logger="repositories.rule_repo")

        priority_map = await repo.get_priority_map()

        assert priority_map[-1005] == 13
        assert "Rule priority map candidate is not numeric" in caplog.text
        assert "bad-candidate" in caplog.text
        assert "-1005" in caplog.text

    async def test_toggle_rule(self, repo, db):
        chat = Chat(telegram_chat_id="-1001", name="Src")
        db.add(chat)
        await db.commit()
        
        target = Chat(telegram_chat_id="-1002", name="Dst")
        db.add(target)
        await db.commit()

        rule = ForwardRule(source_chat_id=chat.id, target_chat_id=target.id, enable_rule=True)
        db.add(rule)
        await db.commit()

        new_status = await repo.toggle_rule(rule.id)
        assert new_status is False
        
        # 刷新对象
        await db.refresh(rule)
        assert rule.enable_rule is False

    async def test_get_all_standard_pagination(self, repo, db):
        # 创建多个规则
        source = Chat(telegram_chat_id="-999", name="Source")
        db.add(source)
        await db.commit()

        for i in range(10):
            target = Chat(telegram_chat_id=f"-{1000+i}", name=f"Target{i}")
            db.add(target)
            await db.commit()
            r = ForwardRule(source_chat_id=source.id, target_chat_id=target.id)
            db.add(r)
        await db.commit()

        items, total = await repo.get_all(page=1, size=5)
        assert len(items) == 5
        assert total >= 10

    async def test_get_all_rules_with_chats(self, repo, db):
        # 创建规则
        source = Chat(telegram_chat_id="-2001", name="SourceA")
        target = Chat(telegram_chat_id="-2002", name="TargetA")
        db.add(source)
        db.add(target)
        await db.commit()
        
        rule = ForwardRule(source_chat_id=source.id, target_chat_id=target.id)
        db.add(rule)
        await db.commit()
        
        rules = await repo.get_all_rules_with_chats()
        assert len(rules) >= 1
        # 验证关联数据是否加载 (通过 DTO 检查，DTo 应该由 model_validate 转换)
        r0 = next(r for r in rules if r.id == rule.id)
        assert r0.source_chat is not None
        assert r0.source_chat.name == "SourceA"

    async def test_get_rules_related_to_chat(self, repo, db):
        # 创建聊天 A, B, C
        chatA = Chat(telegram_chat_id="-3001", name="ChatA")
        chatB = Chat(telegram_chat_id="-3002", name="ChatB")
        chatC = Chat(telegram_chat_id="-3003", name="ChatC")
        db.add_all([chatA, chatB, chatC])
        await db.commit()
        
        # 规则1: A -> B
        rule1 = ForwardRule(source_chat_id=chatA.id, target_chat_id=chatB.id)
        # 规则2: C -> A
        rule2 = ForwardRule(source_chat_id=chatC.id, target_chat_id=chatA.id)
        # 规则3: B -> C (与 A 无关)
        rule3 = ForwardRule(source_chat_id=chatB.id, target_chat_id=chatC.id)
        
        db.add_all([rule1, rule2, rule3])
        await db.commit()
        
        # 获取与 A 相关的规则
        related_to_A = await repo.get_rules_related_to_chat("-3001")
        assert len(related_to_A) == 2
        ids = [r.id for r in related_to_A]
        assert rule1.id in ids
        assert rule2.id in ids
        assert rule3.id not in ids
