import asyncio
import json
import random
import time
import psutil
import gc
from datetime import datetime, timedelta
from core.pipeline import MessageContext
from services.queue_service import FloodWaitException
from core.exceptions import TransientError, PermanentError
from core.config import settings
from core.helpers.memory_policy import resolve_process_memory_thresholds

from core.logging import get_logger, short_id
from services.queue_service import get_messages_queued, send_file_queued
from filters.delay_filter import RescheduleTaskException

logger = get_logger(__name__)

class WorkerService:
    def __init__(self, client, task_repo, pipeline, downloader=None):
        self.client = client
        self.repo = task_repo
        self.pipeline = pipeline
        self.downloader = downloader
        self.running = False
        # 动态休眠策略配置
        self.min_sleep = 0.5  # 最小休眠时间 (秒)
        self.max_sleep = 30.0  # 最大休眠时间 (秒)
        self.current_sleep = self.min_sleep
        self.sleep_increment = 1.0  
        
        # [NEW] 中央分发资源
        self.task_queue = asyncio.Queue(maxsize=settings.WORKER_QUEUE_SIZE)
        self.dispatcher = None # 在 start() 中初始化
        self._dispatcher_wake_unsubscribe = None
        self._stop_event = asyncio.Event()
        self._scale_down_requests = 0
        
        # [NEW] 资源阈值
        self.mem_warning, self.mem_critical = self._resolve_memory_thresholds()
        self.last_gc_time = 0
        self.last_critical_alert = 0 # 上次发送内存紧急告警的时间
        self.critical_mode = False   # 是否处于熔断模式
        self._reconnect_lock = asyncio.Lock()
        self._next_reconnect_at = 0.0
        self._reconnect_cooldown_seconds = 5.0

    def _resolve_memory_thresholds(self):
        return resolve_process_memory_thresholds(
            settings.MEMORY_WARNING_THRESHOLD_MB,
            settings.MEMORY_CRITICAL_THRESHOLD_MB,
        )

    async def start(self):
        """启动 Worker 服务 (动态并发池)"""
        self.running = True
        self._stop_event.clear()
        logger.info(f"WorkerService 启动 (Min: {settings.WORKER_MIN_CONCURRENCY}, Max: {settings.WORKER_MAX_CONCURRENCY})")
        
        self.workers = {} # task -> worker_id
        
        # [Fix] 启动前清理僵尸任务，防止历史遗留的 running 任务占用状态
        try:
            count = await self.repo.rescue_stuck_tasks(timeout_minutes=15)
            if count > 0:
                logger.info(f"♻️ 系统启动救援: 已重置 {count} 个僵尸任务为 PENDING 状态")
        except Exception as e:
            logger.error(f"Failed to rescue tasks during startup: {e}")

        # [Phase 14] 启动中央分发器 (Dispatcher)
        from services.task_dispatcher import TaskDispatcher
        self.dispatcher = TaskDispatcher(self.repo, self.task_queue)
        if hasattr(self.repo, "register_pending_task_listener"):
            self._dispatcher_wake_unsubscribe = (
                self.repo.register_pending_task_listener(self.dispatcher.wake)
            )
        await self.dispatcher.start()

        # 启动初始 Workers
        for i in range(settings.WORKER_MIN_CONCURRENCY):
            self._spawn_worker()

        # 启动弹性伸缩监控
        self._monitor_task = asyncio.create_task(self._monitor_scaling(), name="worker_scaling_monitor")
        
        # [NEW] 启动 Loop Lag 监控
        self._lag_monitor_task = asyncio.create_task(self._monitor_loop_lag(), name="loop_lag_monitor")
        
        # 保持主任务运行（用于接收停止信号），空闲时不做周期性唤醒。
        await self._stop_event.wait()

    def _spawn_worker(self):
        """Spawn a new worker"""
        if len(self.workers) >= settings.WORKER_MAX_CONCURRENCY:
            return

        worker_id = f"worker-{short_id(None, 4)}"
        task = asyncio.create_task(self._worker_loop(worker_id), name=worker_id)
        self.workers[task] = worker_id
        logger.debug(f"Spawned worker {worker_id} (Total: {len(self.workers)})")
        task.add_done_callback(lambda t: self.workers.pop(t, None))

    async def _kill_worker(self):
        """Request one worker to exit after it becomes idle."""
        active_after_pending = len(self.workers) - self._scale_down_requests
        if active_after_pending <= settings.WORKER_MIN_CONCURRENCY:
            return

        try:
            self.task_queue.put_nowait(None)
            self._scale_down_requests += 1
            logger.debug("Scaling down: queued idle worker shutdown request")
        except asyncio.QueueFull:
            logger.debug("Scaling down deferred: task queue is full")

    def _probe_scaling_resources(self):
        """Return CPU usage, process RSS, and load ratio for scaling decisions."""
        try:
            cpu_usage = psutil.cpu_percent(interval=None)
            process = psutil.Process()
            memory_info = process.memory_info()
            memory_mb = memory_info.rss / 1024 / 1024
        except Exception as e:
            logger.warning("Worker resource probe unavailable: %s", e)
            return 0, 0, 0

        try:
            load_1, _load_5, _load_15 = psutil.getloadavg()
            cpu_count = psutil.cpu_count()
            load_ratio = load_1 / cpu_count if cpu_count else 0
        except Exception as e:
            logger.debug("Worker load average unavailable: %s", e)
            load_ratio = 0

        return cpu_usage, memory_mb, load_ratio

    async def _monitor_scaling(self):
        """
        智能化动态伸缩监控 (Resource-Aware & Load-Adaptive)
        策略：
        1. [分级扩容] 根据积压量级决定扩容速度
        2. [系统负载保护] 监控 CPU/内存，高负载时抑制扩容
        3. [平滑缩容] 采用延迟缩容，防止震荡
        """
        logger.info(f"🚀 [WorkerService] 智能化动态伸缩监控已启动 (Max: {settings.WORKER_MAX_CONCURRENCY})")
        
        idle_cycles = 0 # 连续空闲周期计数
        
        while self.running:
            try:
                await asyncio.sleep(10) # 每10秒检查一次
                
                # 获取队列状态
                queue_status = await self.repo.get_queue_status()
                logger.info(f"🔍 [WorkerService] Managed Queue status: {queue_status}")
                # 修复 P0: 使用正确键名 active_queues
                pending_count = queue_status.get('active_queues', 0)
                current_workers = len(self.workers)
                
                # --- 第一步：资源守卫 (Resource Guard) ---
                cpu_usage, memory_mb, load_ratio = self._probe_scaling_resources()
                    
                # 计算内存增速 (用于 Adaptive GC)
                mem_growth = memory_mb - getattr(self, 'last_memory_mb', 0)
                self.last_memory_mb = memory_mb

                # --- 第二步：计算目标 Worker 数 (Target Logic) ---
                # 策略：只要有积压就积极扩容，充分利用空闲资源
                if pending_count == 0:
                    target_count = settings.WORKER_MIN_CONCURRENCY
                else:
                    # 按照积压量级分档
                    if pending_count > 10000:
                        # 极端积压：允许达到最大值
                        target_count = settings.WORKER_MAX_CONCURRENCY
                    elif pending_count > 1000:
                        # 大量积压：每 100 个任务加 1 个 worker
                        target_count = settings.WORKER_MIN_CONCURRENCY + (pending_count // 100)
                    elif pending_count > 100:
                        # 中等积压：每 20 个任务加 1 个 worker
                        target_count = settings.WORKER_MIN_CONCURRENCY + (pending_count // 20)
                    else:
                        # 轻微积压 (1~100)：每 3 个任务加 1 个 worker，至少 +1
                        target_count = settings.WORKER_MIN_CONCURRENCY + max(1, pending_count // 3)

                # 约束目标值
                target_count = max(settings.WORKER_MIN_CONCURRENCY, min(settings.WORKER_MAX_CONCURRENCY, target_count))

                # --- 第三步：执行调整 (Execution & Guard) ---
                log_diagnostic = False
                if idle_cycles % 6 == 0: # 每分钟记录一次诊断
                     log_diagnostic = True
                     # [Fix] 每分钟尝试救援一次超时严重的任务
                     await self.repo.rescue_stuck_tasks(timeout_minutes=20)
                
                if log_diagnostic:
                    logger.info(f"📊 [WorkerService] 系统负载: CPU={cpu_usage}%, Load={load_ratio:.2f}, RAM={memory_mb:.1f}MB | 积压={pending_count}, Workers={current_workers}/{target_count}")

                if current_workers < target_count:
                    # 扩容守卫：资源检查按优先级排列，任何一个触发都阻止扩容
                    scale_blocked = False
                    
                    if cpu_usage > 80 or load_ratio > 1.2:
                        if log_diagnostic:
                            logger.warning(f"⚠️ [WorkerService] 系统高负载，已暂停扩容计划 (CPU={cpu_usage}%, Load={load_ratio:.2f})")
                        scale_blocked = True
                    
                    if memory_mb > self.mem_critical:
                        # 内存危急：触发动态水位线软熔断 (Soft-Start Throttling)
                        current_time = time.time()
                        if current_time - self.last_critical_alert > 300:
                            logger.warning(f"🚨 [ResourceGuard] 内存触及 Fatal 水位 (RSS={memory_mb:.1f}MB > {self.mem_critical}MB)，触发自适应背压降速。")
                            self.last_critical_alert = current_time

                        # 动态调大 Dispatcher 休眠时间，复用 _adaptive_sleep 退避机制
                        if self.dispatcher:
                            self.dispatcher.throttle()
                        
                        # 自适应分代回收 (Adaptive GC)
                        if mem_growth > 50:
                            gc.collect() # 增速过快时深度回收
                        else:
                            gc.collect(1) # 平缓时仅回收年轻代，避免 CPU 毛刺
                        
                        scale_blocked = True
                    elif memory_mb > self.mem_warning: 
                        if log_diagnostic:
                            logger.warning(f"⚠️ [ResourceGuard] 内存触及 Warning 水位 ({memory_mb:.1f}MB > {self.mem_warning}MB)，触发降速与轻量 GC")
                        
                        if self.dispatcher:
                            # 轻度降速
                            self.dispatcher.current_sleep = min(self.dispatcher.current_sleep * 1.5, self.dispatcher.max_sleep)
                            
                        # 轻量级 GC
                        if mem_growth > 20:
                            gc.collect(1)
                            
                        scale_blocked = True
                    else:
                        # 内存回落：不再瞬间拉满，而是随 Dispatcher self.current_sleep 的自然回落进行平滑重置
                        pass
                    
                    if not scale_blocked:
                        diff = target_count - current_workers
                        # 扩容步长更保守：一次最多增加 3 个
                        step = min(diff, 3) 
                        logger.info(f"📈 [WorkerService] 扩容中: +{step} workers (负载正常)")
                        for _ in range(step):
                            self._spawn_worker()

                    idle_cycles = 0 
                
                elif current_workers > target_count:
                    # 缩容策略：更激进地释放资源
                    idle_cycles += 1
                    # 如果 CPU 非常高，立即缩容，不需要等待 3 个周期
                    if cpu_usage > 95 or load_ratio > 2.0:
                         logger.warning(f"🚨 [WorkerService] 极端高负载，紧急释放资源: -2 workers")
                         for _ in range(min(current_workers - settings.WORKER_MIN_CONCURRENCY, 2)):
                             await self._kill_worker()
                         idle_cycles = 0
                    elif idle_cycles >= 3:
                        diff = max(1, (current_workers - target_count) // 2) # 分批次缩容
                        logger.info(f"📉 [WorkerService] 缩容中: -{diff} workers")
                        for _ in range(diff):
                            await self._kill_worker()
                        idle_cycles = 0
                else:
                    idle_cycles = 0

            except Exception as e:
                logger.error(f"Scaling monitor error: {e}", exc_info=True)
                await asyncio.sleep(5)

    async def _monitor_loop_lag(self):
        """[Resource Guard] 监控事件循环延迟 (Loop Lag)"""
        threshold = settings.LOOP_LAG_THRESHOLD_MS / 1000.0
        while self.running:
            try:
                start = asyncio.get_event_loop().time()
                await asyncio.sleep(1.0)
                lag = asyncio.get_event_loop().time() - start - 1.0
                
                if lag > threshold:
                    logger.warning(f"⚠️ [LoopLag] 检测到异步延迟: {lag:.3f}s (阈值: {threshold}s)，系统负载处于高位")
                    # 如果延迟过高，由调度器决定是否降速 (未来可增加联动)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Loop lag monitor error: {e}")
                await asyncio.sleep(10)

    async def _worker_loop(self, worker_id: str):
        """单个 Worker 的工作循环 (支持批量任务处理)"""
        logger.debug(f"[{worker_id}] Loop Started")
        
        while self.running:
            queue_item_acquired = False
            try:
                try:
                      # [Optimization] 改为从中央队列获取任务批次，彻底消除 DB 锁竞争
                      tasks = await self.task_queue.get()
                      queue_item_acquired = True
                      if self.dispatcher:
                          self.dispatcher.wake()
                      if tasks is None:
                          self._scale_down_requests = max(0, self._scale_down_requests - 1)
                          logger.debug(f"[{worker_id}] Graceful scale-down requested")
                          break
                      # 如果 Dispatcher 放入的是单个任务，包装为列表；如果是列表（媒体组），直接使用
                      if not isinstance(tasks, list):
                          tasks = [tasks]
                except asyncio.CancelledError:
                     logger.debug(f"[{worker_id}] Cancelled during queue.get")
                     raise

                # [Fix] 这里的 tasks 永远不为空，因为 Dispatcher 只会在有任务时才放入队列
                # queue.get() 在没有任务时会处于阻塞状态，不消耗 CPU
                
                # 按照 grouped_id 对拉取到的任务进行分组 (媒体组聚合)
                # 如果没有 grouped_id，则视为独立任务
                task_groups = {}
                for t in tasks:
                    gid = t.grouped_id or f"single-{t.id}"
                    if gid not in task_groups:
                        task_groups[gid] = []
                    task_groups[gid].append(t)

                # 依次处理每个任务组
                for gid, group in task_groups.items():
                    main_task = group[0]
                    sub_tasks = group[1:] if len(group) > 1 else []
                    
                    # [关键] 绑定上下文
                    log = logger.bind(worker_id=worker_id, task_id=main_task.id, task_type=main_task.task_type)
                    
                    try:
                        # 确保连接正常；断连属于瞬态错误，任务应延后重试而不是失败或丢失。
                        await self._ensure_connected()
                        await self._process_task_safely(main_task, log, group_tasks=sub_tasks)
                    except (FloodWaitException, TransientError) as e:
                        log.warning(f"group_transient_error", error=str(e), gid=gid)
                        await self._retry_group(group, e, log)
                    except Exception as e:
                        log.error(f"group_processing_failed", error=str(e), gid=gid)

            except asyncio.CancelledError:
                logger.debug(f"[{worker_id}] Cancelled")
                break
            except Exception as e:
                logger.error(f"[{worker_id}] Loop Error: {e}")
                await asyncio.sleep(1)
            finally:
                if queue_item_acquired:
                    self.task_queue.task_done()

    async def _process_task_safely(self, task, log, group_tasks: list = None):
        """处理基础任务的安全封装，支持传入预先锁定的媒体组任务"""
        group_tasks = group_tasks or []
        payload = {}
        chat_id = None
        msg_id = None
        try:
            try:
                payload = json.loads(task.task_data or "{}")
            except Exception as e:
                log.error("task_invalid_json", error=str(e), task_data=task.task_data)
                await self._fail_group([task] + group_tasks, f"Invalid Task JSON: {e}")
                return

            # Simple tasks that don't need message fetching
            if task.task_type in ("message_delete", "custom_task"):
                await self._process_simple_task(task, payload, log, group_tasks)
                return

            # --- Tasks requiring the original message (process_message, download_file, manual_download) ---
            chat_id = payload.get('chat_id')
            msg_id = payload.get('message_id')
            grouped_id = payload.get('grouped_id')

            if not chat_id or not msg_id:
                log.error("task_invalid_payload", task_data=task.task_data)
                await self._fail_group([task] + group_tasks, "Invalid Payload")
                return

            all_related_tasks, valid_messages = await self._fetch_group_messages(
                task, chat_id, msg_id, group_tasks, log
            )
            if not valid_messages:
                return  # _fetch_group_messages already failed the tasks

            primary_message = valid_messages[0]
            from core.helpers.id_utils import get_display_name_async
            chat_display = await get_display_name_async(chat_id)
            log.info(f"🔄 [Worker] 开始处理任务 {short_id(task.id)}: 来源={chat_display}({chat_id}), 消息ID={msg_id}")
            logger.debug(f"📥 [Worker] 成功获取消息对象: ID={primary_message.id}, 内容预览={primary_message.text[:20] if primary_message.text else 'No Text'}")

            await self._dispatch_fetched_task(
                task, payload, chat_id, primary_message,
                valid_messages, grouped_id, group_tasks,
                all_related_tasks, log
            )

        except Exception as e:
            await self._handle_task_exception(e, task, chat_id, msg_id, group_tasks, log)

    # ------------------------------------------------------------------
    # Helper: handle simple tasks that don't require message fetching
    # ------------------------------------------------------------------
    async def _process_simple_task(self, task, payload, log, group_tasks):
        """Handle message_delete and custom_task types."""
        all_tasks = [task] + group_tasks

        if task.task_type == "message_delete":
            chat_id = payload.get('chat_id')
            message_ids = payload.get('message_ids', [])
            if not chat_id or not message_ids:
                log.error("delete_task_invalid_payload", payload=payload)
                await self._fail_group(all_tasks, "Invalid Delete Payload")
                return
            try:
                log.info(f"🗑️ [Worker] 执行删除消息任务: Chat={chat_id}, IDs={message_ids}")
                await self.client.delete_messages(chat_id, message_ids)
                await self._complete_group(all_tasks)
            except Exception as e:
                log.error(f"delete_messages_failed", error=str(e))
                await self._retry_group(all_tasks, e, log)

        elif task.task_type == "custom_task":
            log.info(f"⚙️ [Worker] 处理自定义任务: {payload.get('action')}")
            await self._complete_group(all_tasks)

    # ------------------------------------------------------------------
    # Helper: fetch messages for the current task and its media group
    # ------------------------------------------------------------------
    async def _fetch_group_messages(self, task, chat_id, msg_id, group_tasks, log):
        """Fetch and validate messages for the task and its media-group siblings.

        Returns (all_related_tasks, valid_messages).
        If no valid messages remain, fails the tasks and returns ([], []).
        """
        if group_tasks:
            log.info(f"aggregated_group_tasks", count=len(group_tasks))

        all_message_ids = [msg_id]

        # Parse sibling task message IDs
        valid_group_tasks = []
        for t in group_tasks:
            try:
                p = json.loads(t.task_data or "{}")
                if p.get('message_id'):
                    all_message_ids.append(p.get('message_id'))
                    valid_group_tasks.append(t)
                else:
                    await self.repo.fail(t.id, "Invalid Payload (Group)")
            except Exception as ex:
                logger.warning(f"Failed to parse group task data: {ex}")
                await self.repo.fail(t.id, f"Invalid Task JSON (Group): {ex}")

        all_related_tasks = [task] + valid_group_tasks

        messages = await get_messages_queued(self.client, chat_id, ids=all_message_ids)

        valid_messages = []
        if isinstance(messages, list):
            valid_messages = [m for m in messages if m]
        elif messages:
            valid_messages = [messages]

        if not valid_messages:
            log.debug("task_source_message_not_found", chat_id=chat_id, message_ids=all_message_ids)
            await self._fail_group(all_related_tasks, "Source message not found")
            return ([], [])

        return (all_related_tasks, valid_messages)

    # ------------------------------------------------------------------
    # Helper: dispatch to the correct task-type handler
    # ------------------------------------------------------------------
    async def _dispatch_fetched_task(
        self, task, payload, chat_id, primary_message,
        valid_messages, grouped_id, group_tasks,
        all_related_tasks, log
    ):
        """Route a task (with fetched messages) to the appropriate handler."""
        if task.task_type == "process_message":
            await self._execute_process_message(
                task, payload, chat_id, primary_message,
                valid_messages, grouped_id, group_tasks, all_related_tasks, log
            )
        elif task.task_type == "download_file":
            await self._execute_download_file(
                task, chat_id, primary_message, all_related_tasks, log
            )
        elif task.task_type == "manual_download":
            await self._execute_manual_download(
                task, payload, primary_message, all_related_tasks, log
            )

        # 任务成功
        await self._complete_group(all_related_tasks)
        if group_tasks:
            logger.debug(f"task_completed_with_group: count={len(group_tasks)}")
        else:
            logger.debug("task_completed")

    # ------------------------------------------------------------------
    # Helper: process_message pipeline execution
    # ------------------------------------------------------------------
    async def _execute_process_message(
        self, task, payload, chat_id, primary_message,
        valid_messages, grouped_id, group_tasks, all_related_tasks, log
    ):
        """Execute the full middleware pipeline for a process_message task."""
        ctx = MessageContext(
            client=self.client,
            task_id=task.id,
            chat_id=chat_id,
            message_id=primary_message.id,
            message_obj=primary_message,
            is_group=bool(grouped_id),
            group_messages=valid_messages if grouped_id else [],
            related_tasks=group_tasks
        )
        if payload.get('rule_id'):
            ctx.metadata['target_rule_id'] = int(payload['rule_id'])
        if payload.get('is_history'):
            ctx.metadata['is_history'] = True

        try:
            await self.pipeline.execute(ctx)
        except FloodWaitException as e:
            await self._retry_group(all_related_tasks, e, log)
            return
        except TransientError as e:
            await self._retry_group(all_related_tasks, e, log)
            return
        except PermanentError as e:
            log.error("task_permanent_error", error=str(e), error_type="Permanent")
            await self._fail_group(all_related_tasks, str(e))
            return

    # ------------------------------------------------------------------
    # Helper: download_file task
    # ------------------------------------------------------------------
    async def _execute_download_file(
        self, task, chat_id, primary_message, all_related_tasks, log
    ):
        """Execute a direct download task, bypassing the rule pipeline."""
        if not self.downloader:
            log.error("downloader_not_initialized")
            await self._fail_group(all_related_tasks, "Downloader not initialized")
            return

        sub_folder = str(chat_id)
        try:
            await self.downloader.push_to_queue(primary_message, sub_folder)
        except FloodWaitException as e:
            await self._retry_group(all_related_tasks, e, log)
            return
        except TransientError as e:
            await self._retry_group(all_related_tasks, e, log)
            return
        except PermanentError as e:
            log.error("task_permanent_error", error=str(e), error_type="Permanent")
            await self._fail_group(all_related_tasks, str(e))
            return

    # ------------------------------------------------------------------
    # Helper: manual_download task (with optional forwarding)
    # ------------------------------------------------------------------
    async def _execute_manual_download(
        self, task, payload, primary_message, all_related_tasks, log
    ):
        """Execute a manual download, optionally forwarding to a target chat."""
        if not self.downloader:
            log.error("downloader_not_initialized")
            await self._fail_group(all_related_tasks, "Downloader not initialized")
            return

        try:
            path = await self.downloader.push_to_queue(
                primary_message, sub_folder="manual"
            )
            log.info("manual_download_completed", path=path)

            target_id = payload.get('target_chat_id')
            if target_id:
                try:
                    await send_file_queued(
                        self.client, target_id, path,
                        caption=primary_message.text or ""
                    )
                    log.info(f"manual_forward_completed", target_id=target_id)
                except (FloodWaitException, TransientError):
                    raise
                except Exception as e:
                    log.error(f"manual_forward_failed", target_id=target_id, error=str(e))
        except FloodWaitException as e:
            await self._retry_group(all_related_tasks, e, log)
            return
        except TransientError as e:
            await self._retry_group(all_related_tasks, e, log)
            return
        except PermanentError as e:
            log.error("task_permanent_error", error=str(e), error_type="Permanent")
            await self._fail_group(all_related_tasks, str(e))
            return

    # ------------------------------------------------------------------
    # Helper: unified exception handling for the outer try/except
    # ------------------------------------------------------------------
    async def _handle_task_exception(self, e, task, chat_id, msg_id, group_tasks, log):
        """Handle exceptions raised during task processing."""
        all_tasks = [task] + group_tasks

        if isinstance(e, RescheduleTaskException):
            log.info("task_delay_requested", delay_seconds=e.delay_seconds)
            next_run = datetime.utcnow() + timedelta(seconds=e.delay_seconds)
            await self.repo.reschedule(task.id, next_run)
            if group_tasks:
                for t in group_tasks:
                    await self.repo.reschedule(t.id, next_run)
            return

        if isinstance(e, (FloodWaitException, TransientError)):
            log.warning(f"任务遇到瞬态错误，将重试: 类型={type(e).__name__}, 错误={str(e)}")
            await self._retry_group(all_tasks, e, log)
        elif isinstance(e, PermanentError):
            log.error(f"任务永久失败: 错误={str(e)}, 类型=Permanent, 规则ID={task.rule_id if hasattr(task, 'rule_id') else 'N/A'}", exc_info=True)
            await self._fail_group(all_tasks, str(e))
        else:
            from core.helpers.id_utils import get_display_name_async
            chat_display = await get_display_name_async(chat_id) if chat_id else "unknown"
            log.exception(f"任务未处理错误: 错误={str(e)}, 任务ID={short_id(task.id)}, 任务类型={task.task_type}, 来源={chat_display}({chat_id}), 消息ID={msg_id}")
            await self._fail_group(all_tasks, f"Unhandled: {str(e)}")


    # ... Helper methods stay same ...

    def get_performance_stats(self):
        """[Observability] 获取 Worker 性能与调度统计"""
        # [NEW] 统计信息汇总
        stats = {
            "current_workers": len(self.workers),
            "queue_depth": self.task_queue.qsize() if self.task_queue else 0,
            "max_concurrency": settings.WORKER_MAX_CONCURRENCY,
        }
        
        # 调度器统计
        if getattr(self, 'dispatcher', None):
            stats["dispatcher"] = self.dispatcher.get_stats()
        
        # 精确内存统计 (psutil)
        try:
            import psutil
            process = psutil.Process()
            mem = psutil.virtual_memory()
            stats["memory"] = {
                "process_rss_mb": round(process.memory_info().rss / (1024*1024), 1),
                "sys_available_mb": round(mem.available / (1024*1024), 1),
                "sys_usage_percent": mem.percent
            }
            if hasattr(mem, 'swap_used'):
                stats["memory"]["swap_used_mb"] = round(mem.swap_used / (1024*1024), 1)
        except Exception as e:
            logger.warning("Worker memory stats unavailable: %s", e)
            
        return stats

    async def stop(self):
        """优雅停止 Worker"""
        logger.info("worker_stopping")
        self.running = False
        self._stop_event.set()
        if getattr(self, '_monitor_task', None):
            self._monitor_task.cancel()
        if getattr(self, '_lag_monitor_task', None):
            self._lag_monitor_task.cancel()
        if self._dispatcher_wake_unsubscribe:
            self._dispatcher_wake_unsubscribe()
            self._dispatcher_wake_unsubscribe = None
        
        # Stop dispatcher
        if self.dispatcher:
            await self.dispatcher.stop()
        
        # Cancel all workers
        for task in list(self.workers.keys()):
            task.cancel()
        
        if self.workers:
            await asyncio.gather(*self.workers.keys(), return_exceptions=True)
            
        logger.info("worker_stopped_completely")


    async def _adaptive_sleep(self):
        """自适应休眠：如果没有任务，逐步增加休眠时间，减少资源消耗"""
        # [Phase 13 Optimization] 如果进入深度休眠 (current_sleep 已经达到较大值)，触发 GC
        if self.current_sleep >= self.max_sleep:
             collected = gc.collect()
             if collected > 0:
                 logger.debug(f"[GC] Idle cleanup collected {collected} objects")
                 
        await asyncio.sleep(self.current_sleep)
        if self.current_sleep < self.max_sleep:
            self.current_sleep = min(self.current_sleep + self.sleep_increment, self.max_sleep)

    def _reset_sleep(self):
        """重置休眠时间"""
        self.current_sleep = self.min_sleep

    def _client_is_connected(self) -> bool:
        state = getattr(self.client, "is_connected", False)
        return bool(state() if callable(state) else state)

    async def _ensure_connected(self):
        """确保 Telethon 客户端已连接"""
        if self._client_is_connected():
            return

        loop = asyncio.get_event_loop()
        now = loop.time()
        if now < self._next_reconnect_at:
            wait = self._next_reconnect_at - now
            raise TransientError(
                f"client reconnect cooling down ({wait:.1f}s)",
                context={"retry_delay_seconds": wait, "increment_attempts": False},
            )

        async with self._reconnect_lock:
            if self._client_is_connected():
                return

            now = loop.time()
            if now < self._next_reconnect_at:
                wait = self._next_reconnect_at - now
                raise TransientError(
                    f"client reconnect cooling down ({wait:.1f}s)",
                    context={"retry_delay_seconds": wait, "increment_attempts": False},
                )

            logger.warning("Client disconnected. Attempting to reconnect...")
            try:
                await self.client.connect()
            except Exception as e:
                self._next_reconnect_at = loop.time() + self._reconnect_cooldown_seconds
                logger.error(f"Reconnection failed: {e}")
                raise TransientError(
                    f"client reconnect failed: {e}",
                    context={
                        "retry_delay_seconds": self._reconnect_cooldown_seconds,
                        "increment_attempts": False,
                    },
                ) from e

            if not self._client_is_connected():
                self._next_reconnect_at = loop.time() + self._reconnect_cooldown_seconds
                raise TransientError(
                    "client reconnect failed: still disconnected",
                    context={
                        "retry_delay_seconds": self._reconnect_cooldown_seconds,
                        "increment_attempts": False,
                    },
                )

            self._next_reconnect_at = 0.0
    
    def _calculate_backoff(self, retry_count: int) -> float:
        """
        计算指数退避时间
        公式: min(base * (factor ^ retries), max) + jitter
        """
        # 防止指数爆炸
        safe_retries = min(retry_count, 10)
        
        delay = settings.RETRY_BASE_DELAY * (settings.RETRY_BACKOFF_FACTOR ** safe_retries)
        
        # 截断到最大延迟
        delay = min(delay, settings.RETRY_MAX_DELAY)
        
        # 添加 0-10% 的随机抖动，防止惊群效应 (Thundering Herd)
        jitter = delay * random.uniform(0, 0.1)
        
        return delay + jitter
    
    async def _retry_task(self, task, error, log):
        """
        处理任务重试，根据错误类型和重试次数决定后续操作
        """
        error_context = getattr(error, "context", {}) or {}
        increment_attempts = bool(error_context.get("increment_attempts", True))
        current_retries = task.attempts + (1 if increment_attempts else 0)
        
        # 如果超过最大重试次数，升级为永久失败
        if increment_attempts and current_retries > settings.MAX_RETRIES:
            log.error("task_max_retries_exceeded", retry_count=current_retries, max_retries=settings.MAX_RETRIES, error=str(error))
            await self.repo.fail(task.id, f"Max retries exceeded: {str(error)}")
            return

        # 计算等待时间
        retry_delay = error_context.get("retry_delay_seconds")
        if retry_delay is not None:
            try:
                wait_seconds = max(0.0, float(retry_delay))
            except (TypeError, ValueError):
                wait_seconds = self._calculate_backoff(current_retries)
        elif isinstance(error, FloodWaitException):
            wait_seconds = error.seconds + 1 # 额外多等1秒保险
        else:
            wait_seconds = self._calculate_backoff(current_retries)
            
        next_run = datetime.utcnow() + timedelta(seconds=wait_seconds)
        
        log.warning(
            "task_rescheduled", 
            retry_count=current_retries,
            max_retries=settings.MAX_RETRIES,
            wait_seconds=wait_seconds,
            next_run=next_run.isoformat(),
            error_type=type(error).__name__,
            error=str(error)
        )
        
        # 调用reschedule方法，更新task.next_retry_at字段
        await self.repo.reschedule(
            task.id, 
            next_run,
            increment_attempts=increment_attempts,
        )
        
    async def _retry_group(self, tasks, error, log):
        """
        批量处理任务重试
        """
        for task in tasks:
            await self._retry_task(task, error, log)

    async def _fail_group(self, tasks, error: str):
        """Mark all already-locked tasks in a group as failed."""
        for task in tasks:
            await self.repo.fail(task.id, error)

    async def _complete_group(self, tasks):
        """Mark all already-locked tasks in a group as completed."""
        for task in tasks:
            await self.repo.complete(task.id)
