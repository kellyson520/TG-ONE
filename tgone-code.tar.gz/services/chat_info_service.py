import logging
import asyncio
from typing import Union, Optional, Dict
from datetime import datetime, timedelta
from sqlalchemy import select
from models.models import Chat
from core.helpers.id_utils import resolve_entity_by_id_variants
from telethon import utils as telethon_utils

logger = logging.getLogger(__name__)

class ChatInfoService:
    """
    聊天信息服务
    负责解析 ChatID 到名称的映射，并提供缓存机制。
    """
    def __init__(self, client=None, db=None):
        self.client = client
        self.db = db
        self._name_cache: Dict[str, str] = {}
        self._last_update: Dict[str, datetime] = {}
        self._cache_ttl = timedelta(hours=1)
        self._cache_max_size = 2000
        self._lock = asyncio.Lock()

    def _get_cached_name(self, chat_id: str) -> Optional[str]:
        cached_at = self._last_update.get(chat_id)
        if not cached_at:
            self._name_cache.pop(chat_id, None)
            return None
        if datetime.utcnow() - cached_at > self._cache_ttl:
            self._name_cache.pop(chat_id, None)
            self._last_update.pop(chat_id, None)
            return None
        return self._name_cache.get(chat_id)

    def _set_cached_name(self, chat_id: str, name: str) -> None:
        self._name_cache.pop(chat_id, None)
        self._last_update.pop(chat_id, None)
        self._name_cache[chat_id] = name
        self._last_update[chat_id] = datetime.utcnow()

        overflow = len(self._name_cache) - self._cache_max_size
        if overflow > 0:
            for key in list(self._name_cache.keys())[:overflow]:
                self._name_cache.pop(key, None)
                self._last_update.pop(key, None)

    def set_client(self, client):
        self.client = client

    def set_db(self, db):
        self.db = db

    async def get_chat_name(self, chat_id: Union[int, str]) -> str:
        """
        获取聊天名称
        优先级：内存缓存 > 数据库 > Telegram API
        """
        str_id = str(chat_id)
        
        # 1. 内存缓存
        cached_name = self._get_cached_name(str_id)
        if cached_name:
            return cached_name
        
        async with self._lock:
            # 双重检查
            cached_name = self._get_cached_name(str_id)
            if cached_name:
                return cached_name
            
            # 2. 数据库查询
            name_from_db = await self._get_name_from_db(str_id)
            if name_from_db:
                self._set_cached_name(str_id, name_from_db)
                return name_from_db
            
            # 3. Telegram API 查询 (需要 client)
            if self.client:
                try:
                    entity, _ = await resolve_entity_by_id_variants(self.client, chat_id)
                    if entity:
                        name = telethon_utils.get_display_name(entity)
                        if name:
                            self._set_cached_name(str_id, name)
                            # 异步更新到数据库，不阻塞当前返回
                            asyncio.create_task(self._update_chat_in_db(str_id, entity, name))
                            return name
                except Exception as e:
                    logger.warning(f"Failed to resolve chat name for {chat_id} via API: {e}")
            
            # 降级：返回原始 ID
            return str_id

    async def _get_name_from_db(self, chat_id: str) -> Optional[str]:
        if not self.db:
            return None
        
        try:
            from core.helpers.id_utils import build_candidate_telegram_ids
            candidates = list(build_candidate_telegram_ids(chat_id))
            
            async with self.db.get_session() as session:
                stmt = select(Chat).where(Chat.telegram_chat_id.in_(candidates))
                chat = (await session.execute(stmt)).scalars().first()
                if chat and chat.name:
                    return chat.name
        except Exception as e:
            logger.error(f"Error querying chat name from DB for {chat_id}: {e}")
        
        return None

    async def _update_chat_in_db(self, chat_id: str, entity: any, name: str):
        if not self.db:
            return
        
        try:
            from core.helpers.id_utils import normalize_chat_id
            norm_id = normalize_chat_id(chat_id)
            
            async with self.db.get_session() as session:
                stmt = select(Chat).filter_by(telegram_chat_id=norm_id)
                chat = (await session.execute(stmt)).scalars().first()
                
                if chat:
                    chat.name = name
                    chat.title = name
                    # chat.updated_at does not exist in the model
                else:
                    # 如果不存在，可能是因为还没有规则用到它，但既然查了就记下来
                    chat = Chat(
                        telegram_chat_id=norm_id,
                        name=name,
                        title=name,
                        type=self._get_chat_type(entity)
                    )
                    session.add(chat)
                
                await session.commit()
                logger.debug(f"Updated chat info in DB: {chat_id} -> {name}")
        except Exception as e:
            logger.error(f"Error updating chat info in DB for {chat_id}: {e}")

    def _get_chat_type(self, entity) -> str:
        from telethon.tl.types import Channel, Chat as TGChat, User
        if isinstance(entity, Channel):
            return "channel" if entity.broadcast else "supergroup"
        if isinstance(entity, TGChat):
            return "group"
        if isinstance(entity, User):
            return "private"
        return "unknown"

# 全局单例
chat_info_service = ChatInfoService()
